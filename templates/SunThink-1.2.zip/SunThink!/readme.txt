SunThink!  Solar Electricity System Analysis Software  1.2



To load SunThink!:


To run SunThink!, you must have Scilab installed on your computer.  Scilab is a 
free, open source platform for numerical computation.  It is available for 
download for Windows and other operating systems at <http://www.scilab.org/>. 
(The current version of SunThink was designed with the 5.2.2 release of Scilab, 
and it has only been tested with this release.)

Once Scilab is installed, right click on the SunThink.sce file located beside 
this read-me file, and select the 'Run with scilab' option to load SunThink!



Program notes:


Avoid closing any of the SunThink! windows before you have finished using the 
program.  SunThink! requires all of these windows in order to function properly 
and will close down if any window is closed.

Not every result requires every input be provided (many results can be 
calculated without any utility rate information, for example).  You should be 
prompted if you've left something necessary to the calculation you are 
initiating out.

Blue text is clickable just like a button, triggering an associated action.

Many inputs are set up to be entered in any of several ways.  Click to highlight 
the units you prefer to work with beside the input field in blue.

Entries in scrollable menus must be clicked on to select them.  They will turn 
blue when chosen.

Ellipses on screen mean the program is busy processing away (some calculations 
can take as many as 5 minutes or more to complete.)



External resources:


The Solar Radiation Data Manual for Flat-Plate and Concentrating Collectors 
published by the National Renewable Energy Laboratory, referred to as the 
redbook, provides historical average solar radiation data for many cities 
throughout the United States, and has been made available free online at 
<http://rredc.nrel.gov/solar/pubs/redbook/>.

Weatherbase at <http://www.weatherbase.com/> is one of several online resources
indexing the cloud-coverage history for many cities around the world.

Comments and questions about the SunThink! program may be directed by email to
<reuben@sunwork.org>.
